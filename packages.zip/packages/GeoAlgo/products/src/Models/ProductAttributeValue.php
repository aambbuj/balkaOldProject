<?php

namespace GeoAlgo\Products\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductAttributeValue extends Model
{
    use HasFactory;

    protected $guarded = [];



    public function attributes(){
        return $this->belongsTo(Attribute::class ,'attribute_id' ,'id');
    }
    
    public function attributeValues(){
        return $this->belongsTo(AttributeValue::class ,'attribute_value_id' ,'id');
    }

    public function attribute(){
        return $this->hasMany(Attribute::class ,'id' ,'attribute_id')->with('values');
    }

    public function values(){
        return $this->hasMany(AttributeValue::class ,'id' ,'attribute_value_id');
    }


}


