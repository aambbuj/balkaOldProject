<?php

namespace GeoAlgo\Products\Exports\Sheets;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithTitle;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ProductTypeSheet implements FromCollection, WithTitle, WithStyles
{
    private $month;

    public function __construct(int $month)
    {
        $this->month = $month;
    }

    public function styles(Worksheet $sheet)
    {
        return [
            // Style the first row as bold text.
            1    => ['font' => ['bold' => true, 'italic' => true, 'size' => 20]],
        ];
    }

    /**
     * @return Builder
     */
    public function collection()
    {
        return new Collection([
            ['<b>1</b>', 2, 3, 4, 5, 6, 7]
        ]);
    }

    /**
     * @return string
     */
    public function title(): string
    {
        return 'Month ' . $this->month;
    }
}