@extends('admin.layouts.app')

@section('title', 'Edit Product')

@section('main_content')

@if (count($errors) > 0)
  <div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
       @foreach ($errors->all() as $error)
         <li>{{ $error }}</li>
       @endforeach
    </ul>
  </div>
@endif

               <div class="card-body">
                  <form action="{{ route('product.update') }}" method="POST" id="category_form" class="form row" enctype="multipart/form-data">
                    @csrf
                    <div class="col-sm-8">
                    <div class="form-group">
                      <strong>Product Name</strong>
                      <input type="text" name="name" class="form-control" value="{{ $product->product_name }}" placeholder="Product Name" required>
                    </div>
                    <div class="form-group">
                      <strong>Description</strong>
                      <textarea name="description" class="form-control" id="create-ck" value="" placeholder="Description">{{ $product->product_description }}</textarea>
                    </div>
                    <div class="form-group">
                      <strong>Select Variant</strong>
                      <select class="form-control" id="select_attributs" name="select_attributs">
                        <option hidden value="">Select Variant</option>
                          <option value="normal" selected >Normal</option>
                          <option  value="variant_product" {{ $attributsCount > 0 ? 'selected' : '' }}>Variant Product</option>
                      </select>
                    </div>

                    </div>

                    <div class="col-sm-4">
                      <div class="form-group">
                      <strong>Select Category</strong>
                      <select class="form-control" name="category_id">
                        <option hidden value="">Select Category</option>
                      @foreach($categories as $key => $allCategory)
                        @if($allCategory->subCategories->count() > 0 && $allCategory->parent_id == NULL)
                            <option value="{{ $allCategory->id }}" {{ (!empty($product))?(in_array($allCategory->id,$productCategories) ? 'selected': ''):'' }}>{{ $allCategory->name }}</option>     <!--no padding and margin -->
                                @foreach($allCategory->subCategories as $subCat)
                                    @if($subCat->childrenCategories->count() > 0)
                                          <option  value="{{ $subCat->id }}" {{ (!empty($product))?(in_array($allCategory->id,$productCategories) ? 'selected': ''):'' }} > &nbsp;&nbsp;&nbsp;&nbsp;- {{ $subCat->name }}</option>  <!--padding and margin like 20 px-->
                                        @foreach($subCat->childrenCategories as $childCat)
                                            <option value="{{ $childCat->id }}" {{ (!empty($product))?(in_array($allCategory->id,$productCategories) ? 'selected': ''):'' }} > &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -- {{ $childCat->name }}</option> <!--padding and margin like 30 px-->
                                        @endforeach
                                    @elseif($subCat->childrenCategories->count() == 0)
                                      <option value="{{ $subCat->id }}" {{ (!empty($product))?(in_array($allCategory->id,$productCategories) ? 'selected': ''):'' }} > &nbsp;&nbsp;&nbsp;&nbsp;- {{ $subCat->name }}</option> <!--padding and margin like 20 px-->
                                    @endif
                                @endforeach 
                        @elseif($allCategory->subCategories->count()==0 && $allCategory->parent_id == NULL)
                          <option value="{{ $allCategory->id }}" {{ (!empty($product))?(in_array($allCategory->id,$productCategories) ? 'selected': ''):'' }} >{{ $allCategory->name }}</option>
                        @endif   
                    @endforeach
                      </select>
                    </div>
                    <div class="form-group">
                      <strong>Quantity</strong>
                      <input type="text" name="qty" class="form-control" value="{{ $product->qty_per_unit }}" placeholder="Quantity" required>
                    </div>
                    <div class="form-group">
                      <strong>Price</strong>
                      <input type="text" name="price" class="form-control" value="{{ $product->unit_price }}" placeholder="Price" required>
                    </div>
                    <div class="form-group">
                    <strong>Discount</strong>
                    <input type="text" name="discount" class="form-control" value="{{ $product->discount }}" placeholder="Discount" required>
                    </div>
                    <div class="form-group">
                      <strong>Image</strong>
                      <input type="file" name="image" class="form-control" value="" placeholder="Image" accept="image/*">
                    </div>
                    <!-- <div class="form-group">
                      <input type="file" name="gimage[]" class="form-control" multiple="true" placeholder="Image" accept="image/*" required>
                    </div> -->
                    </div>
                    <div class="form-group">
                      <button type="submit" class="btn btn-primary">Submit</button>
                      <button type="button" class="btn btn-danger" onclick="window.location='{{route('product.index')}}'">Cancel</button>
                     </div> 
                  </form>
                
                    <button id="edit_variant" class="btn btn-info">Edit Variant</button>
                   
                </div>


                <div class="container">
            <!-- The Modal -->
            <div class="modal fade" id="attributsModal">
              <div class="modal-dialog modal-xl">
                <div class="modal-content">
                
                  <!-- Modal Header -->
                  <div class="modal-header">
                    <h4 class="modal-title">Select Attribute </h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                  </div>
                  <!-- Modal body -->
                  <div class="modal-body">
                  <div class="row">
                  @foreach($attributes as $attribute)
                    <div class="col-md-3" >
                    <!-- attributeIds -->
                      <div class="form-check form-check-inline">
                      
                          <input class="form-check-input attribute_ids" type="checkbox" name="attribute_id[]" value="{{ $attribute['attribute_id'] =='' ? $attribute['id'] : $attribute['Pro_attr_value_id'] }}" {{$attribute['attribute_id'] !='' ? 'checked' : ''}}>
                          <label class="form-check-label" for="inlineCheckbox1">{{$attribute['name']}}</label>
                      </div> 

                    <!-- attributeValueIds -->
                    
                  @foreach($attribute['values'] as  $attributeValue)

                    <div class="form-check">
                      <input class="form-check-input attribute_value_ids" type="checkbox" name="attributeValue_id[]" value="{{  $attributeValue['attribute_value_id'] == '' ? $attributeValue['id'] : $attributeValue['Pro_attr_value_id']}}" {{$attributeValue['attribute_value_id'] !='' ? 'checked' : ''}}>
                      <label class="form-check-label" for="defaultCheck1">
                       {{$attributeValue['value']}}
                      </label>
                    </div>
                    @endforeach
                  
                  </div>
                  @endforeach
                  </div>
                      <input type="button" id="save_values" name="save_value" value="Ok" />
                  </div>
                </div>
              </div>
            </div>
            
          </div>
          <button style="display: none;" id="success_call"></button>


     @endsection       

    @section('page-script')

      <script src="https://cdn.ckeditor.com/ckeditor5/24.0.0/classic/ckeditor.js"></script>
     <script>
          ClassicEditor
            .create( document.querySelector( '#create-ck' ) )
                .then( editor => {
                    console.log( editor );
                    } )
                    .catch( error => {
                      console.error( error );
                    } );
    </script>

<!-- <script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script> -->
<script>
// CKEDITOR.replace( '#create-ck' );
</script>

<script type="text/javascript">
  var data=[];
    $(document).ready(function(){
          $("#edit_variant").click(function(e){
            e.preventDefault();
            $("#loading").show();
            $('#attributsModal').modal('show');
            $("#loading").hide();
            
          });
        });
        
        $('#save_values').click(function(){
          attr_id = [];
          value_id = [];
          $('#attributsModal').modal('hide');
          
          $(".attribute_ids:checked").each(function(i){
            attr_id[i] = ($(this).val());
            });

            $(".attribute_value_ids:checked").each(function(i){
                  value_id[i] = $(this).val();
            });

           // var attributeValueObj=[];
           var  attributeValueObj = JSON.parse('<?php echo json_encode($attributes); ?>');

             console.log(attr_id);
             console.log(value_id);
             console.log(attributeValueObj);
              
             for (let i = 0; i < attributeValueObj.length; i++) {
               for (let j = 0; j < attr_id.length; j++) {
                    // if (attributeValueObj[i].id == attr_id[j]) {
                    //   data.push({insert_attribute_id:attr_id[j],});
                    // }
                    for (let k = 0; k < attributeValueObj[i].values.length; k++) {
                        for (let m = 0; m < value_id.length; m++) {
                            if (attributeValueObj[i].values[k].Pro_attr_value_id == value_id[m]) {
                              // data.push({update_attribute_value_id:value_id[m]});
                              }
                              if (attributeValueObj[i].values[k].id == value_id[m] && attributeValueObj[i].id == attr_id[j]) {
                                data.push({insert_attribute_id:attr_id[j],insert_attribute_value_id:value_id[m]});
                              }
                        }
                      }

               }   

             }
             console.log(data)
        })

      $(document).ready(function(){
        $("#category_form").on("submit", function(e){
          e.preventDefault();
          $("#loading").show();
          var  product = JSON.parse('<?php echo json_encode($product); ?>');
          console.log(product);
          var data2;
            data2 = new FormData(this);
            data2.append( 'attribute_value',JSON.stringify(data));
            data2.append( 'product_id',JSON.stringify(product.id));
            $.ajax({
              url: "{{ route('product.update') }}",
              type: "POST",
              data: data2,
            contentType: false,
            cache: false,
            processData:false,
            beforeSend : function(){
              //$("#preview").fadeOut();
              // $("#err").fadeOut();
            },
            success: function(data){
              $("#loading").hide();
              console.log(data); //Call me bhai
              if(data.type == "success"){
                $("#success_call").trigger("click");
                if (data.data>0) {
                  addAttributImage(data.data);
                }

              }else{
                $("#show_error").html(data.msg);
                $("#show_error").show("slow");
              }
            },
            error: function(error){
              $("#show_error").html("Please contact admin");
              $("#show_error").show("slow");
            }
          });
        });
    });

    function addAttributImage(product_id){
   console.log(product_id)
  $.confirm({
      title: 'Add the Product Attributs and value',
      animation: 'zoom',
      closeAnimation: 'scale',
      columnClass: 'col-md-12',
      content: function () {
          var self = this;
          return $.ajax({
              url: "{{ route('product.add-attributs-image') }}",
              data:{
                "_token": "{{ csrf_token() }}",
                product_id:product_id
              },
              dataType: 'json',
              method: 'POST'
          }).done(function (response) {
              // alert(response);
              self.setContent(response.data);
              // self.setContentAppend('<br>Version: ' + response.version);
              // self.setTitle(response.name);
          }).fail(function(data){
              self.setContent(data.responseText);
          });
      },
      type: 'green',
      buttons: {
          formSubmit: {
              text: 'Update',
              btnClass: 'btn-green',
              action: function () {
                  this.$content.find('.form').trigger("submit");
                  return false;
              }
          },
          cancel: function () {
              return true;
          },
      },
      onContentReady: function () {
          // bind to events
          var jc = this;
          this.$content.find('#success_call').on('click', function (e) {
            alert("kjsdjh");
              $message = jc.$content.find('#message_of_call').val();
              jc.close();
              table.draw();
          });
      }
  });
}

  </script>
     @endsection

    @section('page-style')
      <style>
.ck-editor__editable_inline {
    min-height: 300px;
}
</style>
     @endsection